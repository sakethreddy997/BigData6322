#!/usr/bin/python

import sys

for line in sys.stdin:

    key, value = line.strip().split('\t')
    totalpass_count = value.split(',')[3]

    print ("%s\t%d" % (totalpass_count, 1))
