#!/usr/bin/python
import sys

present_passengers = None
present_sum = 0

for line in sys.stdin:
    
    total_pass,total_count = line.strip().split("\t", 1)
    
    try:
        total_count = int(total_count)
    except ValueError:
        continue
    
    if total_pass == present_passengers:
        present_sum += total_count
    else:
        if present_passengers:
            print "%s\t%d" % (present_passengers, present_sum)
        present_passengers = total_pass
        present_sum = total_count

print "%s\t%d" % (present_passengers, present_sum)
