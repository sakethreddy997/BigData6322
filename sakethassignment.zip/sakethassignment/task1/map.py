#!/usr/bin/python

import sys

for line in sys.stdin:
    l = line.strip().split(',')
    taxis_medallion = l[0]
    driver_license = l[1]
    user_id = l[2]
    # fares
    if len(l)==14:
        pick_dtime = l[5]
        print taxis_medallion+','+driver_license+','+user_id+','+pick_dtime+'\tt'+','.join(l[3:5]+l[6:])
    # trips
    elif len(l)==11:
        pick_dtime = l[3]
        print taxis_medallion+','+driver_license+','+user_id+','+pick_dtime+'\tf'+','.join(l[4:])
