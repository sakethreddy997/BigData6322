#!/usr/bin/python
import sys

last_key = ''
fares_list = []
trips_list = []

for line in sys.stdin:
    if not line.startswith('medallion,hack_license,vendor_id,pickup_datetime'):
        present_key, val = line.strip().split('\t')
        if present_key!=last_key:
            if last_key: #do stuff here
                for t in trips_list:
                    for f in fares_list:
                        print last_key+'\t'+t+','+f
                trips_list = []
                fares_list = []
        if val.startswith('t'):
            trips_list.append(val[1:])
        elif val.startswith('f'):
            fares_list.append(val[1:])
	last_key = present_key
for t in trips_list:
    for f in fares_list:
        print last_key+'\t'+t+','+f
