#!/usr/bin/python
import sys

for line in sys.stdin:

    key, value = line.strip().split('\t')

    driver_license = key.split(',')[1]
    taxis_medallion = key.split(',')[0]

    print ("%s\t%s" % (driver_license, taxis_medallion))
