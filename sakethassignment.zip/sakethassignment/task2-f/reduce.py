#!/usr/bin/python
import sys

present_taxismedallion = None
present_driverlicense = None
present_sum = 0
a = {}
for line in sys.stdin:
    
    driver_license, taxis_medallion = line.strip().split("\t", 1)

    
        
    if driver_license != present_driverlicense:
        if present_driverlicense:
            print ("%s\t%d" % (present_driverlicense, len(a)))
            a.clear()
        present_sum = 1

        present_driverlicense = driver_license
    
    a[taxis_medallion] = 1

print ("%s\t%d" % (present_driverlicense, len(a)))
a.clear()
