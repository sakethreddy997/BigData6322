#!/usr/bin/python
import sys

present_fare = None
present_sum = 0

for line in sys.stdin:
    
    fare, count = line.strip().split("\t", 1)
    
    try:
        count = int(count)
    except ValueError:
        continue
    
    if fare == present_fare:
        present_sum += count
    else:
        if present_fare:
            print("%s\t%d" % (present_fare, present_sum))
        present_fare = fare
        present_sum = count

print ("%s\t%d" % (present_fare, present_sum))
