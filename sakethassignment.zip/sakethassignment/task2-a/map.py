#!/usr/bin/python
import sys

for line in sys.stdin:

    key, value = line.strip().split('\t')
    userfare_amount = value.split(',')[11]
    userfare_amount = float(userfare_amount)
    if userfare_amount < 0:
        continue
    if userfare_amount >= 0 and userfare_amount <= 20:
        userfare_amount = '0,20'
    elif userfare_amount >= 20.01 and userfare_amount <= 40:
        userfare_amount = '20.01,40'
    elif userfare_amount >= 40.01 and userfare_amount <= 60:
        userfare_amount = '40.01,60'
    elif userfare_amount >= 60.01 and userfare_amount <= 80:
        userfare_amount = '60.01,80'
    elif userfare_amount > 80:
        userfare_amount = '80.01,infinite'
    print ("%s\t%d" % (userfare_amount, 1))
