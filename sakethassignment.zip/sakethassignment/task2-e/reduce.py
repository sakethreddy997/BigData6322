#!/usr/bin/python
import sys

present_medallion = None
present_sum = 0
total_count = 0
a = {}
for line in sys.stdin:
    
    taxis_medallion, value = line.strip().split("\t", 1)
    pick_date, total_count= value.strip().split(",",1)
        
    
    try:
        total_count = float (total_count)
    except ValueError:
        continue
    
    if taxis_medallion == present_medallion:
        present_sum += total_count
         
    else:
        
        if present_medallion:
            
           calculated_average = float (present_sum/len(a))
           print ("%s\t%d,%.2f" % (present_medallion, present_sum, calculated_average))
           a.clear()
        present_medallion = taxis_medallion
        present_sum = float (total_count)
        calculated_average = total_count
    a[pick_date] = total_count
        
calculated_average = float (present_sum/len(a))
print ("%s\t%d,%.2f" % (present_medallion, present_sum, calculated_average))
a.clear()
