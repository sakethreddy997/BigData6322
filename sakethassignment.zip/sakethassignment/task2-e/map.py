#!/usr/bin/python
import sys
from datetime import datetime
for line in sys.stdin:

    key, value = line.strip().split('\t')
    userpick_datetime = key.split(',')[3]
    taxis_medallion = key.split(',')[0]
    userpick_date = datetime.strptime(userpick_datetime, '%Y-%m-%d %H:%M:%S').strftime('%Y-%m-%d')
    print ("%s\t%s,%d" % (taxis_medallion,userpick_date,1))
