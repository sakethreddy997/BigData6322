#!/usr/bin/python
import sys

current_pickup_date = None
current_total = 0
current_tips_amount = 0

for line in sys.stdin:
    
    pickup_date, revenue = line.strip().split("\t", 1)
    total, tips_amount = revenue.strip().split("&", 1)
    
    try:
        total = float(total)
        tips_amount = float(tips_amount)
    except ValueError:
        continue
    
    if pickup_date == current_pickup_date:
        current_total += total
        current_tips_amount += tips_amount
    else:
        if current_pickup_date:
            print ("%s\t%.2f,%.2f" % (current_pickup_date, current_total, current_tips_amount))
        current_pickup_date = pickup_date
        current_total = total
        current_tips_amount = tips_amount

print ("%s\t%.2f,%.2f" % (current_pickup_date, current_total, current_tips_amount))
